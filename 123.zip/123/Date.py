import os
import pandas as pd

base_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(base_dir, "./Source/Date.xlsx")

print("Reading:", file_path)
df = pd.read_excel(file_path)

df["上班日期"] = pd.to_datetime(df["上班日期"], errors='coerce')
df["休假日期"] = pd.to_datetime(df["休假日期"], errors='coerce')

df["上班月份"] = df["上班日期"].dt.month
df["休假月份"] = df["休假日期"].dt.month

work_count = df.groupby("上班月份")["上班日期"].count().reset_index(name="上班天數")
off_count = df.groupby("休假月份")["休假日期"].count().reset_index(name="休假天數")

total = pd.merge(work_count, off_count, left_on="上班月份", right_on="休假月份", how="outer")

# 使用 fillna 代替 combine_first
total["月份"] = total["上班月份"].fillna(total["休假月份"]).astype(int)
total = total[["月份", "上班天數", "休假天數"]].sort_values("月份").reset_index(drop=True)

month_map = {
    1: "一月", 2: "二月", 3: "三月", 4: "四月", 5: "五月", 6: "六月",
    7: "七月", 8: "八月", 9: "九月", 10: "十月", 11: "十一月", 12: "十二月"
}
total["月份"] = total["月份"].map(month_map)

out_path = os.path.join(base_dir, "./Source/Date_total.xlsx")
total.to_excel(out_path, index=False)

print("Generate:", out_path)
