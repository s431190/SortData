import os
import shutil
import pandas as pd
from datetime import timedelta

# ===== 一開始先刪除 01~08 資料夾 =====
folders_all = ['01','02','02x','03','04','05','06','07','08','09','10','11']
for f in folders_all:
    if os.path.exists(f):
        shutil.rmtree(f)
        print(f"Deleted folder: {f}")
        
# ==================================== 使用者控制區 ==================================== #
# 設置檔案名稱
# inf1: 打卡紀錄
# inf2: 請假紀錄
# inf6: 出差紀錄
inf1 = './Source/All.xlsx'
inf2 = './Source/2.xls'
inf6 = './Source/3.xlsx'

# 設置月份
target_month = "六月"  # 可改成想要的月份

# folder_mode 控制資料夾建立
# 1: 產生全部資料夾 (01~08)
# 2: 只保留部分其餘刪除
folder_mode = 1
folders_all = ['01','02','02x','03','04','05','06','07','08','09','10','11']
folders_final = ['02','02x','10','11']

def create_folders(mode):
    if mode == 1:
        for f in folders_all:
            os.makedirs(f, exist_ok=True)
    elif mode == 2:
        for f in folders_final:
            os.makedirs(f, exist_ok=True)

create_folders(folder_mode)
# ==================================== 使用者控制區 ==================================== #

# ===== Step 1: 分工號存檔 & 未滿8小時存檔 =====
df1 = pd.read_excel(inf1)
outdir1 = '01'
outdir2 = '02'
outdir2x = '02x'

for name, group in df1.groupby('工號'):
    if folder_mode != 2:
        outpath1 = os.path.join(outdir1, f'{name}_all.xlsx')
        group.to_excel(outpath1, index=False)
        
        under8 = group[group['時數'] < 8]
        if not under8.empty:
            outpath2 = os.path.join(outdir2, f'{name}_under8.xlsx')
            under8.to_excel(outpath2, index=False)
        
        over8 = group[group['時數'] >= 8]
        if not over8.empty:
            outpath2x = os.path.join(outdir2x, f'{name}_over8.xlsx')
            over8.to_excel(outpath2x, index=False)

# ===== Step 2: 分工號存請假資料 =====
df2 = pd.read_excel(inf2)
outdir3 = '03'

if folder_mode != 2:
    for name, group in df2.groupby('工號'):
        outpath1 = os.path.join(outdir3, f'{name}_leave.xlsx')
        group.to_excel(outpath1, index=False)

print("Step 1-2 Done.")

# ===== Step 3: 拆分期間欄位 =====
inf3 = "03"
outdir4 = "04"

if folder_mode != 2:
    for file in os.listdir(inf3):
        if not file.endswith(".xlsx"):
            continue
        file_path = os.path.join(inf3, file)
        df3 = pd.read_excel(file_path)
        
        if "期間" not in df3.columns:
            print(f"Warning: {file} not exist, Pass.")
            continue

        split_cols = df3["期間"].str.split("~", n=1, expand=True)
        df3["期間開始"] = pd.to_datetime(split_cols[0].str.strip(), errors="coerce")
        df3["期間結束"] = pd.to_datetime(split_cols[1].str.strip(), errors="coerce")
        df3 = df3.drop(columns=["期間"])

        cols = list(df3.columns)
        if "請假時數(hr)" in cols:
            idx = cols.index("時數(hr)")
            cols.insert(idx, cols.pop(cols.index("期間結束")))
            cols.insert(idx, cols.pop(cols.index("期間開始")))
            df3 = df3[cols]

        output_path = os.path.join(outdir4, f'{os.path.splitext(file)[0]}_split.xlsx')
        df3.to_excel(output_path, index=False)
        #print(f"Finish splitting：{file}")

print("Step 3 Done.")

# ===== Step 4: 時數大於8拆分每日8小時 =====
input_dir = "04"
output_dir = "05"
if folder_mode != 2:
    os.makedirs(output_dir, exist_ok=True)

holiday_file = "./Source/Date.xlsx"
holiday_df = pd.read_excel(holiday_file)

holiday_df["休假日期"] = pd.to_datetime(holiday_df["休假日期"]).dt.date
holiday_dates = holiday_df["休假日期"].dropna().tolist()

for file in os.listdir(input_dir):
    if not file.endswith(".xlsx"):
        continue

    file_path = os.path.join(input_dir, file)
    df = pd.read_excel(file_path)
    new_rows = []

    hours_col = "時數(hr)"

    for idx, row in df.iterrows():
        total_hours = row.get(hours_col, 0)
        start_time = row.get("期間開始")

        if pd.isna(total_hours) or pd.isna(start_time):
            new_rows.append(row)
            continue

        start_time = pd.to_datetime(start_time)

        if total_hours <= 8:
            # 檢查是否落在休假日，若是則往後遞延
            next_time = start_time
            while next_time.date() in holiday_dates:
                next_time += timedelta(days=1)
            row["期間開始"] = next_time
            new_rows.append(row)
        else:
            full_days = int(total_hours // 8)
            remainder = total_hours % 8
            current_day = start_time

            for i in range(full_days):
                # 找出下一個非休假日
                while current_day.date() in holiday_dates:
                    current_day += timedelta(days=1)
                new_row = row.copy()
                new_row["期間開始"] = current_day
                new_row["期間結束"] = row.get("類別", "X")
                new_row[hours_col] = 8
                new_rows.append(new_row)
                current_day += timedelta(days=1)

            if remainder > 0:
                while current_day.date() in holiday_dates:
                    current_day += timedelta(days=1)
                new_row = row.copy()
                new_row["期間開始"] = current_day
                new_row["期間結束"] = row.get("類別", "X")
                new_row[hours_col] = remainder
                new_rows.append(new_row)

    df_new = pd.DataFrame(new_rows)
    output_path = os.path.join(output_dir, f'{os.path.splitext(file)[0]}8.xlsx')
    df_new.to_excel(output_path, index=False)

print("Step 4 Done.")

# ===== Step 5: 合併未滿8小時+請假資料(未過濾) =====
dir02 = "02"
dir05 = "05"
outdir06 = "06"
if folder_mode != 2:
    os.makedirs(outdir06, exist_ok=True)

for file02 in os.listdir(dir02):
    if not file02.endswith(".xlsx"):
        continue
    
    file_path02 = os.path.join(dir02, file02)
    df02 = pd.read_excel(file_path02)
    
    df02["歸屬日期"] = pd.to_datetime(df02["歸屬日期"]).dt.date
    hours_col02 = "時數"

    base_name = file02.split("_under8")[0]
    file05_name = f"{base_name}_leave_split8.xlsx"
    file05_path = os.path.join(dir05, file05_name)
    
    if os.path.exists(file05_path):
        df05 = pd.read_excel(file05_path)
        df05["日期"] = pd.to_datetime(df05["期間開始"]).dt.date
        df05 = df05[["日期", "時數(hr)", "類別"]].copy()
    else:
        df05 = pd.DataFrame(columns=["日期", "時數(hr)", "類別"])

    df02_idx = df02.set_index("歸屬日期")
    for idx, row in df05.iterrows():
        date = row["日期"]
        leave_hours = row["時數(hr)"]
        leave_type = row["類別"]
        if date in df02_idx.index:
            df02_idx.loc[date, hours_col02] += leave_hours
        else:
            new_row = {}
            for col in df02.columns:
                if col in ["工號", "姓名", "部門", "部門名稱"]:
                    new_row[col] = df02.iloc[0][col]
                elif col == hours_col02:
                    new_row[col] = leave_hours
                else:
                    new_row[col] = leave_type
            new_row["歸屬日期"] = date
            df02_idx = pd.concat([df02_idx, pd.DataFrame([new_row]).set_index("歸屬日期")])

    df_out = df02_idx.reset_index(drop=False)
    output_file = f"{os.path.splitext(file02)[0]}_add.xlsx"
    output_path = os.path.join(outdir06, output_file)
    df_out.to_excel(output_path, index=False)
    #print(f"Finish merging：{file02}")

print("Step 5 Done.")

# ===== Step 6: 出差分工號存檔 =====

outdir7 = '07'
df6 = pd.read_excel(inf6)
for name, group in df6.groupby('工號'):
    if folder_mode != 2:
        outpath7 = os.path.join(outdir7, f'{name}_trip.xlsx')
        group.to_excel(outpath7, index=False)
        
print("Step 6 Done.")

# ===== Step 7: 補足出差表格 =====
dir07 = "07"  
outdir8 = "08"
os.makedirs(outdir8, exist_ok=True)

holiday_file = "./Source/Date.xlsx"
holiday_df = pd.read_excel(holiday_file)
holiday_df["休假日期"] = pd.to_datetime(holiday_df["休假日期"]).dt.date
holiday_dates = holiday_df["休假日期"].dropna().tolist()

for file in os.listdir(dir07):
    if not file.endswith(".xlsx"):
        continue

    file_path = os.path.join(dir07, file)
    df = pd.read_excel(file_path)
    new_rows = []

    for idx, row in df.iterrows():
        start_date = pd.to_datetime(row.get("開始日期"))
        end_date = pd.to_datetime(row.get("結束日期"))

        if pd.isna(start_date) or pd.isna(end_date):
            new_rows.append(row)
            continue

        current_day = start_date
        while current_day <= end_date:
            # 休假日就跳過
            if current_day.date() not in holiday_dates:
                new_row = row.copy()
                new_row["開始日期"] = current_day
                new_row["結束日期"] = current_day
                new_rows.append(new_row)
            current_day += timedelta(days=1)

    df_new = pd.DataFrame(new_rows)
    
    # 修改輸出檔名
    base_name7 = os.path.splitext(file)[0]
    output_file = f"{base_name7}_split.xlsx"
    output_path = os.path.join(outdir8, output_file)
    df_new.to_excel(output_path, index=False)

print("Step 7 Done.")

# ===== Step 8: 總合併所有檔案(未過濾) =====
dir06 = "06"
dir08 = "08"
outdir09 = "09"
os.makedirs(outdir09, exist_ok=True)

trip_data = []
for file08 in os.listdir(dir08):
    if file08.endswith(".xlsx"):
        df08 = pd.read_excel(os.path.join(dir08, file08))
        trip_data.append(df08)
if trip_data:
    df08_all = pd.concat(trip_data, ignore_index=True)
else:
    df08_all = pd.DataFrame()

for file06 in os.listdir(dir06):
    if not file06.endswith(".xlsx"):
        continue

    emp_id = file06.split("_")[0]
    file06_path = os.path.join(dir06, file06)
    out_path = os.path.join(outdir09, f"{emp_id}_cat_all.xlsx")
    df06 = pd.read_excel(file06_path)

    if "歸屬日期" not in df06.columns:
        df06["歸屬日期"] = pd.NA

    df_trip = df08_all[df08_all["工號"].astype(str) == emp_id]

    new_rows = []
    if not df_trip.empty:
        dept = df06["部門"].iloc[0] if "部門" in df06.columns and not df06.empty else ""
        dept_name = df06["部門名稱"].iloc[0] if "部門名稱" in df06.columns and not df06.empty else ""

        for _, row in df_trip.iterrows():
            start_date = pd.to_datetime(row["開始日期"]).date()

            converted = pd.to_datetime(df06["歸屬日期"], errors="coerce").dt.date
            mask_same_date = converted == start_date
            if mask_same_date.any():
                # 用反向掩碼保留非相同日期的列
                df06 = df06[~mask_same_date].reset_index(drop=True)

            new_rows.append({
                "歸屬日期": start_date,
                "工號": str(row["工號"]),
                "姓名": row["姓名"],
                "部門": dept,
                "部門名稱": dept_name,
                "最早刷卡日期": "出差",
                "最早刷卡時間": "出差",
                "最晚刷卡日期": "出差",
                "最晚刷卡時間": "出差",
                "時數": 8
            })

    if new_rows:
        df_new = pd.DataFrame(new_rows)
        df06 = pd.concat([df06, df_new], ignore_index=True)

    df06.to_excel(out_path, index=False)

print("Step 8 Done.")

# ===== Step 9: 過濾掉滿8小、存在於2x日期與休假日 =====
dir02 = "02x"
dir09 = "09"
outdir10 = "10"
os.makedirs(outdir10, exist_ok=True)

holiday_file = "./Source/Date.xlsx"
holiday_df = pd.read_excel(holiday_file)
holiday_df["休假日期"] = pd.to_datetime(holiday_df["休假日期"], errors="coerce").dt.date
holiday_dates = set(holiday_df["休假日期"].dropna().tolist())

record_02 = {}
for file02 in os.listdir(dir02):
    if file02.endswith(".xlsx"):
        emp_id = file02.split("_")[0]
        df02 = pd.read_excel(os.path.join(dir02, file02))

        if "歸屬日期" not in df02.columns:
            continue

        df02["歸屬日期"] = pd.to_datetime(df02["歸屬日期"], errors="coerce").dt.date
        valid_dates = df02["歸屬日期"].dropna().unique().tolist()
        record_02[emp_id] = set(valid_dates)

for file09 in os.listdir(dir09):
    if not file09.endswith(".xlsx"):
        continue

    emp_id = file09.split("_")[0]
    file09_path = os.path.join(dir09, file09)
    out_path = os.path.join(outdir10, f"{emp_id}_under8_all_list.xlsx")

    df09 = pd.read_excel(file09_path)

    # 時數 < 8
    if "時數" in df09.columns:
        df09["時數"] = pd.to_numeric(df09["時數"], errors="coerce")
        df09 = df09[df09["時數"] < 8]

    # 移除 02x 已存在的日期
    if "歸屬日期" in df09.columns:
        df09["歸屬日期"] = pd.to_datetime(df09["歸屬日期"], errors="coerce").dt.date
        if emp_id in record_02:
            existing_dates = record_02[emp_id]
            df09 = df09[~df09["歸屬日期"].isin(existing_dates)]

        # 移除休假日
        df09 = df09[~df09["歸屬日期"].isin(holiday_dates)]

    df09.to_excel(out_path, index=False)

print("Step 9 Done.")

# ===== Step 10: 按部門整合未滿8小時資料 =====
from openpyxl import load_workbook
from openpyxl.utils import get_column_letter

# ===== 參數設定 =====
dir10 = "10"
outdir11 = "11"
os.makedirs(outdir11, exist_ok=True)

date_total = pd.read_excel("./Source/Date_total.xlsx")
date_total_dict = dict(zip(date_total["月份"], date_total["上班天數"]))
if target_month in date_total_dict:
    total_workdays = date_total_dict[target_month]
else:
    raise ValueError(f"{target_month} 在 Date_total.xlsx 中不存在")

# ===== 收集所有 10 資料 =====
all_data = []
for file10 in os.listdir(dir10):
    if file10.endswith(".xlsx"):
        df = pd.read_excel(os.path.join(dir10, file10))
        if not df.empty and "部門" in df.columns:
            all_data.append(df)

if not all_data:
    print("No DATA.")
else:
    df_all = pd.concat(all_data, ignore_index=True)
    df_all["時數"] = pd.to_numeric(df_all["時數"], errors="coerce")

    for dept, group in df_all.groupby("部門"):
        dept = str(dept).strip() or "未分類部門"
        out_path = os.path.join(outdir11, f"Dep_{dept}_all.xlsx")

        # === Sheet 1: 明細 ===
        group = group.sort_values(["工號", "歸屬日期"])
        with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
            group.to_excel(writer, index=False, sheet_name="明細")

        # === Sheet 2: 統計 ===
        summary = (
            group.groupby(["工號", "姓名"])
            .agg(
                次數=("歸屬日期", "count"),
                平均時數=("時數", "mean")
            )
            .reset_index()
        )

        summary["平均時數"] = summary["平均時數"].round(2)
        # 計算未滿8小出勤率
        summary["未滿8小出勤率"] = (summary["次數"] / total_workdays * 100).round(2)

        emp_count = summary["工號"].nunique()

        with pd.ExcelWriter(out_path, engine="openpyxl", mode="a") as writer:
            summary.to_excel(writer, index=False, sheet_name="統計")

        # === 在 Excel 加上部門平均 ===
        wb = load_workbook(out_path)
        ws = wb["統計"]

        last_row = ws.max_row
        headers = [cell.value for cell in ws[1]]
        count_col = headers.index("次數") + 1
        avg_col = headers.index("平均時數") + 1
        rate_col = headers.index("未滿8小出勤率") + 1

        count_letter = get_column_letter(count_col)
        avg_letter = get_column_letter(avg_col)
        rate_letter = get_column_letter(rate_col)

        sum_row = last_row + 2

        # 部門人數
        ws[f"A{sum_row-1}"] = f"部門人數：{emp_count}"

        # 部門平均（四捨五入到小數點兩位）
        ws[f"A{sum_row}"] = "部門平均"
        ws[f"{count_letter}{sum_row}"] = f"=ROUND(AVERAGE({count_letter}2:{count_letter}{last_row}),2)"
        ws[f"{avg_letter}{sum_row}"] = f"=ROUND(AVERAGE({avg_letter}2:{avg_letter}{last_row}),2)"
        ws[f"{rate_letter}{sum_row}"] = f"=ROUND(AVERAGE({rate_letter}2:{rate_letter}{last_row}),2)"

        wb.save(out_path)
    print("Step 10 Done.")
























# ---- 執行完畢後，如果 folder_mode = 2，刪除中間資料夾 ----
if folder_mode == 2:
    for f in set(folders_all) - set(folders_final):
        if os.path.exists(f):
            shutil.rmtree(f)
