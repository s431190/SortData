import warnings
warnings.filterwarnings('ignore')
import pandas as pd

input_file = "./Source/1.xlsx"
output_file = "./Source/All.xlsx"

df = pd.read_excel(input_file, header=None, dtype=str)

TARGET_COLS = ["工號", "姓名", "部門", "部門名稱", "歸屬日期",
               "最早刷卡時間", "最晚刷卡時間", "時數"]

def is_header_row(row):
    return all(col in row.values for col in TARGET_COLS[:-1])

header_indices = [i for i, row in df.iterrows() if is_header_row(row)]
header = df.iloc[header_indices[0]].tolist()

def fix_employee_id(x):
    x = str(x).strip()
    if not x:
        return x
    if x[0].isalpha():
        return x
    if x.isdigit():
        return str(int(x))
    return x

data_rows = []
for start in header_indices:
    for _, row in df.iloc[start+1:].iterrows():
        if any("門禁刷卡查詢" in str(x) for x in row if pd.notna(x)):
            continue
        if any(str(x).startswith("備註說明") for x in row if pd.notna(x)):
            continue
        text = "".join(str(x) for x in row if pd.notna(x))
        if text.strip() == "":
            continue
        if is_header_row(row):
            break
        data_rows.append(row.tolist())

clean_df = pd.DataFrame(data_rows, columns=header)
clean_df["工號"] = clean_df["工號"].apply(fix_employee_id)
clean_df = clean_df[TARGET_COLS]

clean_df["歸屬日期"] = pd.to_datetime(clean_df["歸屬日期"], errors="coerce")

def emp_sort_key(x):
    x = str(x)
    if x.isdigit():
        return (0, int(x))
    return (1, x)

clean_df = clean_df.sort_values(by=["工號", "歸屬日期"],
                                key=lambda col: col.map(emp_sort_key),
                                ascending=[True, True])

clean_df.to_excel(output_file, index=False)
print("Create 1.xlsx!")
